inline void init(string filename)
{
 srand(time(0));
 freopen(filename.c_str(),"w",stdout);
}
inline void pin(int x)
{
     printf("%d",x);
}
inline void pin_(int x)
{
     printf("%d ",x);
}
inline void pli(int x)
{
     printf("%d\n",x);
}
inline void nl()
{
     printf("\n");
}
