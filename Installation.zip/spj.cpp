#include "mode.h"
#include "spj.h"
int main()
{
    setspj();
    closespj();
    return 0;
}
