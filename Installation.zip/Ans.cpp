#include "mode.h"

int main(int argc, char *argv[])
{
    setIO("sample");
    
    closeIO();
    return EXIT_SUCCESS;
}
