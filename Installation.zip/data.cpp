#include "mode.h"
#include "iodata.h"

using namespace std;

int main(int argc, char *argv[])
{
    init("sample.in");
    
    closeIO();
    return EXIT_SUCCESS;
}
